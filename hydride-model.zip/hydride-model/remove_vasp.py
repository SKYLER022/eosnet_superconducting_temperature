import csv

# 读取 CSV 文件并修改文件名
input_file = "id_prop.csv"  # 替换为你的文件名
output_file = "output.csv"

with open(input_file, "r") as infile, open(output_file, "w", newline="") as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)
    
    for row in reader:
        row[0] = row[0].replace(".vasp", "")  # 去掉 .vasp 后缀
        writer.writerow(row)

print(f"处理完成，结果已保存到 {output_file}")

